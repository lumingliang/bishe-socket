
@include('editor::head')
<div class="editor">
	<textarea id='myEditor'></textarea>
</div>