@extends('app')


@section('content')

@if($results[0]) 
    <h1>{{$results[1]}}欢迎您首次登陆</h1>
@endif


@endsection