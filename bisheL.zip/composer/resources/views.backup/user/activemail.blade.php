<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  </head>
<body>
  <a href="{{ URL('user/registerEmailCheck?code='.$activeationcode) }}" target="_blank"><h1>点击激活你的账号</h1></a>
</body>
</html>
