@extends('layout')

@section('header')

<header class="section">
        <div class="container">
            <div class="row">
                    <i class="icon-flag icon-md"></i>
                    <im src="//localhost/img/profile.png">
                    <div class="intro-text">
                        <span class="name">任何时候都要保持简单</span>
                        <hr class="star-light">
                    </div>
            </div>
        </div>
        <button class="btn btn-lg btn-priamry" id="slide_up"></button>
</header>

@endsection