@extends('layout')

@section('header')
	<header class="section">
		<div class="container">
			<h3>header大标题</h3>
		</div>
	</header>
@endsection