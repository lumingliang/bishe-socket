<?php

return [
    // 宽度
    'width'=>'890px',
    'uploadUrl'=>'upload'
];